<?php
session_start();

// Guardando o nome na sessão
$_SESSION["usuario"] = $_POST["nome"];

// Criando cookie com a cor favorita
setcookie("cor", $_POST["cor"], time() + 3600);

echo "Dados salvos com sucesso! <br><br>";

echo "<a href='perfil.php'>Ir para o perfil</a>";
?>